import speech_recognition as sr
import webbrowser
import pyttsx3


# pip install pocketsphinx

recognizer = sr.Recognizer()
engine = pyttsx3.init()


def speak(text):
    engine.say(text)
    engine.runAndWait()


def processCommand(c):
    if "open lower" in c.lower():
        webbrowser.open("https://google.com")
    elif "open facebook" in c.lower():
        webbrowser.open("https://facebook.com")
    elif "open youtube" in c.lower():
        webbrowser.open("https://youtube.com")
    elif "open linkedin" in c.lower():
        webbrowser.open("https://linkedin.com")        


if __name__== "__main__":
    speak("Initializing Jarvis....")
    while True:
        # Listen for the wake word "Jarvis"
        # obtain audio from the microphone
        r = sr.Recognizer()
        with sr.Microphone() as source:
            print("LIstening...")
            audio = r.listen(source, phrase_time_limit=1)



        # recognize speech using Sphinx
    print("recognizing...")
    try:
        with sr.Microphone() as source:
             print("LIstening...")
             audio = r.listen(source, timeout=2, phrase_time_limit=1)
        word = r.recognize_google_cloud(audio)
        if(word.lower() == "Jarvis"):
            speak("Ya")
            # listen for command
            with sr.Microphone() as source:
             print("jarvis Active...")
             audio = r.listen(source)
             command = r.recognize_google_cloud(audio)

             processCommand(command)

             


    except Exception as e:
        print("Error; {0}".format(e))