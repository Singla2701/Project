music = { 
    "Stealth": "https://www.youtube.com/watch?v=89ihROphQJM",
    "pyaar": "https://www.youtube.com/watch?v=siw7-MTgE4s",
    "soorma": "https://www.youtube.com/watch?v=rnyrDk4G68g",
    "best": "https://www.youtube.com/watch?v=NDgEyXmonoE&list=PLqDyiQp0D" 
}